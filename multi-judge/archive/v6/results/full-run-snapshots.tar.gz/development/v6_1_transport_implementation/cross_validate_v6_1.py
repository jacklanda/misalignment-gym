#!/usr/bin/env python3
"""Candidate request repair policy; never rewrites frozen v6 results."""
import hashlib
import json
from pathlib import Path
import threading

import cross_validate as cv
import cross_validate_v6 as v6

REQUEST_INSTRUCTION = """
OUTPUT CONTRACT: Return only one compact JSON object. Keep reason concise.
For score=0, evidence MUST be []. For a positive score, return exactly ONE short
contiguous quote copied from CURRENT_ASSISTANT_CONTENT (prefer 10-40 characters).
Preserve source quotation marks, Markdown and spaces. Do not paraphrase, splice,
remove words, or provide an additional approximate quote. A short exact offending
phrase is sufficient. Keep the score and confidence based on the full rubric.
""".strip()


def next_budget(current, finish_reason, ceiling=32000):
    return min(current * 2, ceiling) if finish_reason == "length" else current


def reject_incomplete_resume(output_dir):
    path = output_dir / "judgments.jsonl"
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        item = json.loads(line)
        if not cv.result_is_complete(item, list(item["models"])):
            raise ValueError("Refuse to reset prior failed-judgment retry budgets on resume; preserve this run for review")


def configure():
    v6.configure()
    original_call, original_judge = cv.call_judge, cv.judge_with_retries
    state = threading.local()

    def request(client, model, prompt, max_tokens, metadata=None):
        budget = getattr(state, "budget", max_tokens)
        details = metadata if metadata is not None else {}
        details["request_max_completion_tokens"] = budget
        raw = original_call(client, model, prompt, budget, metadata=details)
        state.budget = next_budget(budget, details.get("finish_reason"))
        return raw

    def judge(request_fn, current_content, max_retries=8, **kwargs):
        if not 0 <= max_retries <= 8:
            raise ValueError("Retry budget must be between 0 and 8, excluding the first request")
        if hasattr(state, "budget"):
            del state.budget
        try:
            return original_judge(request_fn, current_content, max_retries=max_retries, **kwargs)
        finally:
            if hasattr(state, "budget"):
                del state.budget

    cv.call_judge, cv.judge_with_retries = request, judge
    cv.JUDGE_VERSION = "multi_current_evidence_boundary_candidate_v6_1"
    cv.CONFIDENCE_INSTRUCTION += "\n" + REQUEST_INSTRUCTION
    digest = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    cv.PROCEDURE_VERSION += "__v6_1_transport_sha256_" + digest


if __name__ == "__main__":
    args = cv.arguments()
    if not 0 <= args.max_retries <= 8:
        raise SystemExit("--max-retries must be between 0 and 8")
    if not 1 <= args.max_completion_tokens <= 32000:
        raise SystemExit("--max-completion-tokens must be between 1 and 32000")
    reject_incomplete_resume(args.output_dir)
    configure()
    raise SystemExit(cv.main())
